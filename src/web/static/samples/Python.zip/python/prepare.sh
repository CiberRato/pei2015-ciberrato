# We are using python code for this robot, it won't need compilation
# Although it may need libraries.
#
# To install additional libraries that you may need, use:
# sudo apt-get install library_name (Debian system)
echo "Unzip sample_code.zip.."
unzip sample_code.zip
